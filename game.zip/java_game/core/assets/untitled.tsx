<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tily1" tilewidth="4" tileheight="4" tilecount="66625" columns="325">
 <image source="tile_set1.jpg" width="1300" height="823"/>
</tileset>
