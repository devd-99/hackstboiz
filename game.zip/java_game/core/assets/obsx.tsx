<?xml version="1.0" encoding="UTF-8"?>
<tileset name="obs" tilewidth="4" tileheight="4" tilecount="40000" columns="200">
 <image source="obs.jpg" width="800" height="800"/>
</tileset>
