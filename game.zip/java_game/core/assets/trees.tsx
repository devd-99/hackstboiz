<?xml version="1.0" encoding="UTF-8"?>
<tileset name="trees" tilewidth="4" tileheight="4" tilecount="14976" columns="96">
 <image source="trees.png" width="384" height="624"/>
</tileset>
