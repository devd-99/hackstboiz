package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.Body;

public class Player extends Box2d_sprites {
    int control_switch=2;
    private int numCrystals;
    private int totalCrystals;


    public Player(Body body) {

        super(body);
        //texture_1();


            setAnimation(texture_1(), 1 / 12f);


    }
    public TextureRegion[] texture_1(){
        Texture tex = jgame.res.getTexture("run_right");
        TextureRegion[] sprites = TextureRegion.split(tex, 40, 40)[0];
        return sprites;
    }


    public void collectCrystal() { numCrystals++; }
    public int getNumCrystals() { return numCrystals; }
    public void setTotalCrystals(int i) { totalCrystals = i; }
    public int getTotalCyrstals() { return totalCrystals; }
}
