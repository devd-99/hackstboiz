package com.mygdx.game;

import com.badlogic.gdx.physics.box2d.*;

public class MyContactListener implements ContactListener {
    private boolean playeronground;
    private int numFootContacts;
    public void beginContact(Contact contact){
        Fixture fa = contact.getFixtureA();
        Fixture fb = contact.getFixtureB();
       if(fa.getUserData()!=null&&fa.getUserData().equals("foot")){
           numFootContacts++;//sets true when foot fixture is in contact with the ground

        }
        if(fb.getUserData()!=null&&fb.getUserData().equals("foot")){
            numFootContacts++;// sets true when foot fixture is in contact with the ground(setting both because box2d picks randomly)

        }

    }


    public void endContact(Contact contact){
        Fixture fa = contact.getFixtureA();
        Fixture fb = contact.getFixtureB();
        if(fa.getUserData()!=null&&fa.getUserData().equals("foot")){
            numFootContacts--;//sets false when player is in air

        }
        if(fb.getUserData()!=null&&fb.getUserData().equals("foot")){
            numFootContacts--;

        }
    }
    public boolean isPlayeronground(){
        return numFootContacts>0;
    }
    public void preSolve(Contact c,Manifold manifold){}//not used, declared because implemented contactlistner
    public void postSolve(Contact c, ContactImpulse v){}//not used, declared because implemented contactlistner
}
