package com.mygdx.game.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.mygdx.game.jgame;

public class DesktopLauncher {
	public static void main (String[] arg) {
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		config.title = jgame.title;
		config.width = jgame.width*jgame.scale;
		config.height = jgame.height*jgame.scale;
		new LwjglApplication(new jgame(), config);
	}
}
