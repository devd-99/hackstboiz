<?xml version="1.0" encoding="UTF-8"?>
<tileset name="spikes" tilewidth="4" tileheight="4" tilecount="1400" columns="35">
 <image source="Spikes_in_Sonic_the_Hedgehog_4.png" width="142" height="163"/>
</tileset>
