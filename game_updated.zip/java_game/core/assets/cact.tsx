<?xml version="1.0" encoding="UTF-8"?>
<tileset name="cact" tilewidth="4" tileheight="4" tilecount="9216" columns="96">
 <image source="cact'.png" width="384" height="384"/>
</tileset>
