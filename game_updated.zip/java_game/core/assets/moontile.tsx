<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Moon" tilewidth="4" tileheight="4" tilecount="6700" columns="100">
 <image source="Moon.jpg" width="403" height="269"/>
</tileset>
