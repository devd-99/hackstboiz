<?xml version="1.0" encoding="UTF-8"?>
<tileset name="star" tilewidth="32" tileheight="32" tilecount="42" columns="6">
 <image source="star.png" width="217" height="243"/>
</tileset>
